맥북 단축키 월페이퍼 5종  /  MacBook Shortcut Wallpapers
======================================================
해상도 : 3456 x 2234  (16인치 맥북 프로 네이티브)
기준   : macOS Tahoe 26 / Apple 공식 한국어 지원 문서

01-basic.png       기본 필수 단축키
02-screenshot.png  화면 캡처 단축키
03-finder.png      파인더 파일 관리
04-window.png      창과 앱 전환
05-text.png        텍스트 편집 커서

[적용 방법]
시스템 설정 -> 배경화면 -> '사용자의 사진' -> 사진 추가...

개인 사용은 자유롭게 하셔도 됩니다.
재배포하실 때는 출처를 남겨 주세요.

출처 : 맥부킷  https://doonablog.tistory.com
